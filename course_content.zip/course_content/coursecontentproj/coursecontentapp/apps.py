from django.apps import AppConfig


class CoursecontentappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'coursecontentapp'
